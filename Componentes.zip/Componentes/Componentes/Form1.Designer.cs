﻿namespace Componentes
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPDF = new System.Windows.Forms.Button();
            this.btnWMP = new System.Windows.Forms.Button();
            this.btnWeb = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnPDF
            // 
            this.btnPDF.Location = new System.Drawing.Point(88, 167);
            this.btnPDF.Name = "btnPDF";
            this.btnPDF.Size = new System.Drawing.Size(135, 51);
            this.btnPDF.TabIndex = 0;
            this.btnPDF.Text = "PDF";
            this.btnPDF.UseVisualStyleBackColor = true;
            this.btnPDF.Click += new System.EventHandler(this.btnPDF_Click);
            // 
            // btnWMP
            // 
            this.btnWMP.Location = new System.Drawing.Point(292, 167);
            this.btnWMP.Name = "btnWMP";
            this.btnWMP.Size = new System.Drawing.Size(132, 51);
            this.btnWMP.TabIndex = 1;
            this.btnWMP.Text = "Windows Media Player";
            this.btnWMP.UseVisualStyleBackColor = true;
            this.btnWMP.Click += new System.EventHandler(this.btnWMP_Click);
            // 
            // btnWeb
            // 
            this.btnWeb.Location = new System.Drawing.Point(481, 167);
            this.btnWeb.Name = "btnWeb";
            this.btnWeb.Size = new System.Drawing.Size(125, 51);
            this.btnWeb.TabIndex = 2;
            this.btnWeb.Text = "Web Browser";
            this.btnWeb.UseVisualStyleBackColor = true;
            this.btnWeb.Click += new System.EventHandler(this.btnWeb_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnWeb);
            this.Controls.Add(this.btnWMP);
            this.Controls.Add(this.btnPDF);
            this.Name = "Form1";
            this.Text = "Menu Componentes";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnPDF;
        private System.Windows.Forms.Button btnWMP;
        private System.Windows.Forms.Button btnWeb;
    }
}

